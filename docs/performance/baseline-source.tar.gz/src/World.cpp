#include "infinite/World.hpp"
#include <algorithm>
#include <sqlite3.h>
#include <stdexcept>
#include <zstd.h>

namespace infinite {
RegionCache::RegionCache(const Universe& u, size_t budget, size_t jobs)
    : universe_(u), budget_(budget), maxJobs_(std::max(size_t(1), jobs)) {}
RegionCache::~RegionCache() {
    {
        std::lock_guard lock(mutex_);
        for (auto& [key, e] : entries_)
            if (e.cancel)
                e.cancel->store(true);
    }
    tasks_.wait();
}
void RegionCache::beginFrame() {
    std::lock_guard lock(mutex_);
    ++frame_;
}
std::shared_ptr<const Geometry> RegionCache::request(const Node& node, unsigned lod) {
    lod = geometryDetail(node.address.kind(), lod);
    return schedule(
        node, node.address.str() + "@", static_cast<int>(lod),
        [this, node, lod](const std::atomic<bool>* cancel) {
            return GeometryGenerator(universe_).generate(node, lod, cancel);
        },
        [lod](const Geometry& g) { return std::abs(static_cast<double>(g.detail) - lod); });
}
std::shared_ptr<const Geometry> RegionCache::requestSection(const Node& node, const Address& anchor,
                                                            int bucket) {
    if (!node.address.ancestorOf(anchor) || node.address == anchor)
        throw std::invalid_argument("Section must refine its parent");
    return schedule(
        node, node.address.str() + "|" + anchor.str() + "@", bucket,
        [this, node, anchor, bucket](const std::atomic<bool>* cancel) {
            return GeometryGenerator(universe_).section(node, anchor, bucket, cancel);
        },
        [bucket](const Geometry& g) { return std::abs(g.logUnits - bucket * .5); });
}
std::shared_ptr<const Geometry>
RegionCache::schedule(const Node& node, const std::string& prefix, int variant,
                      std::function<std::shared_ptr<Geometry>(const std::atomic<bool>*)> generate,
                      std::function<double(const Geometry&)> score) {
    if (node.seed != seedOf(node.address, universe_.seed()))
        throw std::invalid_argument("Foreign universe node in cache");
    std::string key = prefix + std::to_string(variant);
    std::lock_guard lock(mutex_);
    auto it = entries_.find(key);
    if (it != entries_.end()) {
        it->second.used = frame_;
        if (it->second.geometry) {
            ++stats_.hits;
            return it->second.geometry;
        }
    } else if (stats_.pending < maxJobs_) {
        ++stats_.misses;
        ++stats_.pending;
        auto cancel = std::make_shared<std::atomic<bool>>(false);
        entries_[key] = {{}, cancel, frame_, true};
        tasks_.run([this, key, generate = std::move(generate), cancel]() {
            std::shared_ptr<Geometry> geometry;
            std::string error;
            try {
                geometry = generate(cancel.get());
            } catch (const std::exception& e) {
                error = e.what();
            }
            std::lock_guard guard(mutex_);
            --stats_.pending;
            auto found = entries_.find(key);
            if (found == entries_.end())
                return;
            found->second.running = false;
            found->second.cancel.reset();
            if (!error.empty()) {
                stats_.error = error;
                entries_.erase(found);
                return;
            }
            if (!geometry || cancel->load() || geometry->bytes() > budget_) {
                ++stats_.cancelled;
                entries_.erase(found);
                return;
            }
            stats_.bytes += geometry->bytes();
            stats_.lastMs = geometry->generationMs;
            ++stats_.completed;
            found->second.geometry = std::move(geometry);
            trim();
        });
    }
    // Retain an existing representation until the requested refinement is ready.
    std::shared_ptr<const Geometry> fallback;
    double best = 1e9;
    for (auto& [k, e] : entries_)
        if (k.starts_with(prefix) && e.geometry) {
            double delta = score(*e.geometry);
            if (delta < best) {
                best = delta;
                fallback = e.geometry;
                e.used = frame_;
            }
        }
    return fallback;
}
void RegionCache::trim() {
    while (stats_.bytes > budget_ || entries_.size() > 96) {
        auto victim = entries_.end();
        for (auto i = entries_.begin(); i != entries_.end(); ++i)
            if (!i->second.running && (victim == entries_.end() || i->second.used < victim->second.used))
                victim = i;
        if (victim == entries_.end())
            break;
        if (victim->second.geometry)
            stats_.bytes -= victim->second.geometry->bytes();
        entries_.erase(victim);
    }
}
void RegionCache::finishFrame() {
    std::lock_guard lock(mutex_);
    for (auto& [key, e] : entries_)
        if (e.running && frame_ > e.used + 3)
            e.cancel->store(true);
    trim();
}
GenerationStats RegionCache::stats() const {
    std::lock_guard lock(mutex_);
    return stats_;
}
void RegionCache::wait() {
    tasks_.wait();
}
void RegionCache::clear() {
    wait();
    std::lock_guard lock(mutex_);
    entries_.clear();
    stats_.bytes = 0;
}

static void check(int result, sqlite3* db) {
    if (result != SQLITE_OK && result != SQLITE_DONE && result != SQLITE_ROW)
        throw std::runtime_error(sqlite3_errmsg(db));
}
struct Statement {
    sqlite3_stmt* value = nullptr;
    sqlite3* db;
    Statement(sqlite3* d, const char* sql) : db(d) {
        check(sqlite3_prepare_v2(db, sql, -1, &value, nullptr), db);
    }
    ~Statement() {
        sqlite3_finalize(value);
    }
    void text(int i, std::string_view s) {
        check(sqlite3_bind_text(value, i, s.data(), static_cast<int>(s.size()), SQLITE_TRANSIENT), db);
    }
    int step() {
        int r = sqlite3_step(value);
        check(r, db);
        return r;
    }
};
Persistence::Persistence(const std::string& file, uint64_t seed) : universe_(std::to_string(seed)) {
    int result = sqlite3_open_v2(file.c_str(), &db_,
                                 SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX, nullptr);
    if (result != SQLITE_OK) {
        std::string error = db_ ? sqlite3_errmsg(db_) : "SQLite allocation failed";
        if (db_)
            sqlite3_close(db_);
        db_ = nullptr;
        throw std::runtime_error(error);
    }
    sqlite3_busy_timeout(db_, 2000);
    try {
        exec("PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; CREATE TABLE IF NOT EXISTS "
             "modifications(universe TEXT NOT NULL,address TEXT NOT NULL,bytes INTEGER NOT NULL,payload BLOB "
             "NOT NULL,PRIMARY KEY(universe,address)); CREATE TABLE IF NOT EXISTS state(universe TEXT "
             "PRIMARY KEY,payload TEXT NOT NULL); PRAGMA user_version=1;");
    } catch (...) {
        sqlite3_close(db_);
        db_ = nullptr;
        throw;
    }
}
Persistence::~Persistence() {
    if (db_)
        sqlite3_close(db_);
}
void Persistence::exec(const char* sql) {
    char* error = nullptr;
    int result = sqlite3_exec(db_, sql, nullptr, nullptr, &error);
    if (result != SQLITE_OK) {
        std::string message = error ? error : sqlite3_errmsg(db_);
        sqlite3_free(error);
        throw std::runtime_error(message);
    }
}
void Persistence::mark(const Address& a, std::string_view note) {
    if (note.size() > 1024 * 1024)
        throw std::invalid_argument("Marker exceeds 1 MiB");
    std::vector<char> compressed(ZSTD_compressBound(note.size()));
    size_t size = ZSTD_compress(compressed.data(), compressed.size(), note.data(), note.size(), 3);
    if (ZSTD_isError(size))
        throw std::runtime_error(ZSTD_getErrorName(size));
    Statement s(db_, "INSERT INTO modifications VALUES(?1,?2,?3,?4) ON CONFLICT(universe,address) DO UPDATE "
                     "SET bytes=excluded.bytes,payload=excluded.payload");
    s.text(1, universe_);
    s.text(2, a.str());
    check(sqlite3_bind_int64(s.value, 3, static_cast<int64_t>(note.size())), db_);
    check(sqlite3_bind_blob(s.value, 4, compressed.data(), static_cast<int>(size), SQLITE_TRANSIENT), db_);
    s.step();
}
std::optional<std::string> Persistence::marker(const Address& a) const {
    Statement s(db_, "SELECT bytes,payload FROM modifications WHERE universe=?1 AND address=?2");
    s.text(1, universe_);
    s.text(2, a.str());
    if (s.step() != SQLITE_ROW)
        return {};
    int64_t bytes = sqlite3_column_int64(s.value, 0);
    if (bytes < 0 || bytes > 1024 * 1024)
        throw std::runtime_error("Corrupt marker length");
    std::string out(static_cast<size_t>(bytes), '\0');
    size_t result = ZSTD_decompress(out.data(), out.size(), sqlite3_column_blob(s.value, 1),
                                    static_cast<size_t>(sqlite3_column_bytes(s.value, 1)));
    if (ZSTD_isError(result) || result != out.size())
        throw std::runtime_error("Corrupt marker payload");
    return out;
}
size_t Persistence::markerCount() const {
    Statement s(db_, "SELECT COUNT(*) FROM modifications WHERE universe=?1");
    s.text(1, universe_);
    s.step();
    return static_cast<size_t>(sqlite3_column_int64(s.value, 0));
}
void Persistence::saveState(std::string_view state) {
    Statement s(
        db_, "INSERT INTO state VALUES(?1,?2) ON CONFLICT(universe) DO UPDATE SET payload=excluded.payload");
    s.text(1, universe_);
    s.text(2, state);
    s.step();
}
std::optional<std::string> Persistence::loadState() const {
    Statement s(db_, "SELECT payload FROM state WHERE universe=?1");
    s.text(1, universe_);
    if (s.step() != SQLITE_ROW)
        return {};
    return std::string(reinterpret_cast<const char*>(sqlite3_column_text(s.value, 0)),
                       static_cast<size_t>(sqlite3_column_bytes(s.value, 0)));
}
} // namespace infinite
