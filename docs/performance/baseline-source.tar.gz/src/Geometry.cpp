#include "infinite/Geometry.hpp"
#include <FastNoise/FastNoise.h>
#include <algorithm>
#include <bit>
#include <chrono>
#include <cmath>
#include <numbers>
#include <stdexcept>

namespace infinite {
constexpr double pi = std::numbers::pi;
uint32_t rgba(glm::vec3 c, float a) {
    auto byte = [](float v) { return static_cast<uint32_t>(std::clamp(v, 0.f, 1.f) * 255.f + .5f); };
    return byte(c.r) | (byte(c.g) << 8) | (byte(c.b) << 16) | (byte(a) << 24);
}
glm::vec3 elementColor(uint8_t e) {
    switch (e) {
    case 6:
        return {.63f, .65f, .7f};
    case 8:
        return {1, .29, .16};
    case 14:
        return {.38, .76, .95};
    case 26:
        return {.89, .66, .35};
    case 12:
        return {.54, .86, .26};
    default:
        return {.85, .9, 1};
    }
}
static Vertex vertex(glm::dvec3 p, glm::vec3 color) {
    return {static_cast<float>(p.x), static_cast<float>(p.y), static_cast<float>(p.z), rgba(color)};
}
static glm::vec3 shade(glm::vec3 c, glm::dvec3 n) {
    if (glm::dot(n, n) < 1e-28)
        n = {0, 1, 0};
    double l = .19 + .81 * std::max(0.0, glm::dot(glm::normalize(n), glm::normalize(glm::dvec3(-.5, .8, 1))));
    return c * static_cast<float>(l);
}
void addLine(Mesh& m, glm::dvec3 a, glm::dvec3 b, glm::vec3 color) {
    auto i = static_cast<uint32_t>(m.vertices.size());
    m.vertices.push_back(vertex(a, color));
    m.vertices.push_back(vertex(b, color));
    m.indices.push_back(i);
    m.indices.push_back(i + 1);
}
void appendSphere(Mesh& m, glm::dvec3 center, double radius, glm::vec3 color, unsigned rings,
                  unsigned sectors, bool emissive) {
    auto base = static_cast<uint32_t>(m.vertices.size());
    for (unsigned y = 0; y <= rings; ++y)
        for (unsigned x = 0; x <= sectors; ++x) {
            double a = 2 * pi * x / sectors, b = pi * y / rings;
            glm::dvec3 n(std::sin(b) * std::cos(a), std::cos(b), std::sin(b) * std::sin(a));
            m.vertices.push_back(vertex(center + n * radius, emissive ? color : shade(color, n)));
        }
    for (unsigned y = 0; y < rings; ++y)
        for (unsigned x = 0; x < sectors; ++x) {
            auto a = base + y * (sectors + 1) + x, b = a + sectors + 1;
            m.indices.insert(m.indices.end(), {a, b, a + 1, a + 1, b, b + 1});
        }
}
std::vector<TerrainLeaf> terrainLeaves(glm::dvec3 view, unsigned maxLevel) {
    std::vector<TerrainLeaf> out;
    std::function<void(Tile)> visit = [&](Tile t) {
        double dot = glm::dot(tileDirection(t), view);
        bool split = t.level < maxLevel && (t.level < 1 || dot > -.2 + static_cast<double>(t.level) * .16);
        if (!split) {
            out.push_back({t});
            return;
        }
        for (unsigned y = 0; y < 2; ++y)
            for (unsigned x = 0; x < 2; ++x)
                visit({t.face, t.level + 1, t.x * 2 + x, t.y * 2 + y});
    };
    for (int face = 0; face < 6; ++face)
        visit({face, 0, 0, 0});
    return out;
}
static void surfaceGrid(Mesh& m, unsigned size, const std::function<glm::dvec3(double, double)>& point,
                        const std::function<glm::vec3(double, double, glm::dvec3)>& color) {
    uint32_t base = static_cast<uint32_t>(m.vertices.size());
    for (unsigned y = 0; y <= size; ++y)
        for (unsigned x = 0; x <= size; ++x) {
            double u = static_cast<double>(x) / size, v = static_cast<double>(y) / size;
            auto p = point(u, v);
            m.vertices.push_back(vertex(p, color(u, v, p)));
        }
    for (unsigned y = 0; y < size; ++y)
        for (unsigned x = 0; x < size; ++x) {
            auto a = base + y * (size + 1) + x, b = a + size + 1;
            m.indices.insert(m.indices.end(), {a, a + 1, b, a + 1, b + 1, b});
        }
}
static void sdfMesh(Mesh& mesh, const std::function<double(glm::dvec3)>& sdf, unsigned cells,
                    const std::function<glm::vec3(glm::dvec3)>& color, const std::atomic<bool>* cancel,
                    double halfExtent = 1.3) {
    // Marching tetrahedra of a bounded SDF. The same density and zero surface
    // are used at every resolution; detail changes sampling, not object identity.
    constexpr int tetra[6][4] = {{0, 5, 1, 6}, {0, 1, 2, 6}, {0, 2, 3, 6},
                                 {0, 3, 7, 6}, {0, 7, 4, 6}, {0, 4, 5, 6}};
    constexpr int offsets[8][3] = {{0, 0, 0}, {1, 0, 0}, {1, 1, 0}, {0, 1, 0},
                                   {0, 0, 1}, {1, 0, 1}, {1, 1, 1}, {0, 1, 1}};
    constexpr int edges[6][2] = {{0, 1}, {0, 2}, {0, 3}, {1, 2}, {1, 3}, {2, 3}};
    double step = 2 * halfExtent / cells;
    size_t side = cells + 1;
    std::vector<double> field(side * side * side);
    auto index = [&](unsigned x, unsigned y, unsigned z) { return (z * side + y) * side + x; };
    for (unsigned z = 0; z <= cells; ++z) {
        if (cancel && cancel->load())
            return;
        for (unsigned y = 0; y <= cells; ++y)
            for (unsigned x = 0; x <= cells; ++x)
                field[index(x, y, z)] = sdf(glm::dvec3(x, y, z) * step - glm::dvec3(halfExtent));
    }
    auto tri = [&](glm::dvec3 a, glm::dvec3 b, glm::dvec3 c) {
        auto center = (a + b + c) / 3.0;
        double e = .002;
        glm::dvec3 normal(sdf(center + glm::dvec3(e, 0, 0)) - sdf(center - glm::dvec3(e, 0, 0)),
                          sdf(center + glm::dvec3(0, e, 0)) - sdf(center - glm::dvec3(0, e, 0)),
                          sdf(center + glm::dvec3(0, 0, e)) - sdf(center - glm::dvec3(0, 0, e)));
        if (glm::dot(glm::cross(b - a, c - a), normal) < 0)
            std::swap(b, c);
        auto col = shade(color(center), normal);
        uint32_t i = static_cast<uint32_t>(mesh.vertices.size());
        mesh.vertices.push_back(vertex(a, col));
        mesh.vertices.push_back(vertex(b, col));
        mesh.vertices.push_back(vertex(c, col));
        mesh.indices.insert(mesh.indices.end(), {i, i + 1, i + 2});
    };
    for (unsigned z = 0; z < cells; ++z) {
        if (cancel && cancel->load())
            return;
        for (unsigned y = 0; y < cells; ++y)
            for (unsigned x = 0; x < cells; ++x) {
                std::array<glm::dvec3, 8> p;
                std::array<double, 8> v;
                for (int i = 0; i < 8; ++i) {
                    auto& o = offsets[i];
                    p[i] = glm::dvec3(x + o[0], y + o[1], z + o[2]) * step - glm::dvec3(halfExtent);
                    v[i] = field[index(x + o[0], y + o[1], z + o[2])];
                }
                for (auto& t : tetra) {
                    std::array<glm::dvec3, 4> cut;
                    int count = 0;
                    for (auto& e : edges) {
                        int a = t[e[0]], b = t[e[1]];
                        if ((v[a] < 0) != (v[b] < 0))
                            cut[count++] = glm::mix(p[a], p[b], v[a] / (v[a] - v[b]));
                    }
                    if (count == 3)
                        tri(cut[0], cut[1], cut[2]);
                    else if (count == 4) {
                        auto center = (cut[0] + cut[1] + cut[2] + cut[3]) * .25;
                        auto axis = glm::normalize(cut[0] - center);
                        auto normal = glm::normalize(glm::cross(cut[1] - center, axis));
                        auto other = glm::cross(normal, axis);
                        std::sort(cut.begin(), cut.end(), [&](auto a, auto b) {
                            return std::atan2(glm::dot(a - center, other), glm::dot(a - center, axis)) <
                                   std::atan2(glm::dot(b - center, other), glm::dot(b - center, axis));
                        });
                        tri(cut[0], cut[1], cut[2]);
                        tri(cut[0], cut[2], cut[3]);
                    }
                }
            }
    }
}
static void microTint(Mesh& mesh, const Node& n, const std::function<glm::dvec3(glm::dvec3)>& localPoint) {
    if (mesh.vertices.empty())
        return;
    // SIMD noise is batched and strict FP; only the micro-inclusion tint
    // uses it. Identity and all authoritative density fields use scalar hashes.
    auto noise = FastNoise::New<FastNoise::Simplex>();
    size_t count = mesh.vertices.size();
    std::vector<float> x(count), y(count), z(count), out(count);
    for (size_t i = 0; i < count; ++i) {
        auto v = mesh.vertices[i];
        auto p = localPoint({v.x, v.y, v.z});
        x[i] = static_cast<float>(p.x * 13);
        y[i] = static_cast<float>(p.y * 13);
        z[i] = static_cast<float>(p.z * 13);
    }
    noise->GenPositionArray3D(out.data(), static_cast<int>(count), x.data(), y.data(), z.data(), 0, 0, 0,
                              static_cast<int>(n.seed & 0x7fffffff));
    for (size_t i = 0; i < count; ++i) {
        auto& v = mesh.vertices[i];
        // Growth zoning follows the habit's c axis. Foliation appears only in
        // strained hosts; graphite/ice retain their basal layering.
        float layer;
        if (n.environment.mineral == Mineral::Graphite || n.environment.mineral == Mineral::Ice)
            layer = .78f + .22f * std::cos(z[i] * 3);
        else if (n.rock.type == RockType::Metamorphic)
            layer = .75f + .25f * std::sin(y[i] * 3 + out[i] * .5f);
        else
            layer = .87f + .13f * std::sin(std::sqrt(x[i] * x[i] + y[i] * y[i]) * 2 + out[i] * .3f);
        uint32_t c = v.color;
        glm::vec3 col((c & 255) / 255.f, ((c >> 8) & 255) / 255.f, ((c >> 16) & 255) / 255.f);
        v.color = rgba(col * layer);
    }
}
std::shared_ptr<Geometry> GeometryGenerator::generate(const Node& n, unsigned lod,
                                                      const std::atomic<bool>* cancel) const {
    auto begin = std::chrono::steady_clock::now();
    auto g = std::make_shared<Geometry>();
    Random r{n.seed};
    auto kind = n.address.kind();
    lod = geometryDetail(kind, lod);
    g->address = n.address;
    g->referenceFrame = n.address;
    g->logUnits = n.frame.logRadius;
    g->seed = n.seed;
    g->descriptor = descriptorFingerprint(n);
    g->detail = lod;
    if (kind == Kind::Cosmic) {
        for (uint64_t i = 0; i < 18000; ++i) {
            if (cancel && cancel->load())
                return {};
            glm::dvec3 p(r.signedUnit(i * 4) * .96, r.signedUnit(i * 4 + 1) * .96,
                         r.signedUnit(i * 4 + 2) * .96);
            double density = universe_.cosmicDensity(p * 4.0, n.seed);
            if (r.unit(i * 4 + 3) < density * .55)
                g->particles.push_back({p, glm::vec3(.2, .45, .7) * static_cast<float>(density), .003f});
        }
    } else if (kind == Kind::Galaxy) {
        size_t count = 5000 + lod * 3500;
        for (size_t i = 0; i < count; ++i) {
            if (cancel && cancel->load())
                return {};
            auto star = universe_.starSample(n, i);
            float intensity = static_cast<float>(.35 + .65 * std::min(star.mass / 3, 1.0));
            g->particles.push_back({star.position, star.color * intensity,
                                    static_cast<float>(.0006 + .0011 * std::min(star.mass, 3.0)), i});
        }
        for (size_t i = 0; i < static_cast<size_t>(3000 * n.galaxy.gasFraction); ++i) {
            g->particles.push_back({universe_.gasSample(n, i), {.11f, .16f, .22f}, .003f});
        }
    } else if (kind == Kind::System) {
        double radius = n.stellarRadiusMetres / std::pow(10.0, n.frame.logRadius);
        auto starColor = stellarColor(n.temperatureK);
        appendSphere(g->solid, {}, radius, starColor, 16, 24, true);
        g->particles.push_back({{}, starColor, static_cast<float>(radius * 2.5)});
        if (n.companions)
            appendSphere(g->solid, {radius * 9, 0, 0}, radius * .6, starColor * .8f, 10, 16, true);
        for (auto a : universe_.children(n)) {
            auto p = universe_.describe(a);
            for (int i = 0; i < 160; ++i) {
                auto orbit = p.orbit;
                orbit.phase = static_cast<double>(i) * 2 * pi / 160;
                auto b = orbit;
                b.phase = static_cast<double>(i + 1) * 2 * pi / 160;
                addLine(g->lines, keplerPosition(orbit, 0) / std::pow(10.0, n.frame.logRadius),
                        keplerPosition(b, 0) / std::pow(10.0, n.frame.logRadius), {.11f, .19f, .24f});
            }
        }
        for (int i = 0; i < 1400; ++i) {
            double a = r.unit(100 + i * 2) * 2 * pi, rad = .16 + .035 * r.signedUnit(101 + i * 2);
            g->particles.push_back(
                {glm::dvec3(std::cos(a) * rad, r.signedUnit(i + 5000) * .002, std::sin(a) * rad),
                 {.3f, .25f, .19f},
                 .00014f});
        }
    } else if (kind == Kind::Planet) {
        auto leaves = terrainLeaves({.3, .2, 1}, std::min(lod, 3u));
        double radius = std::pow(10.0, n.frame.logRadius);
        for (auto leaf : leaves) {
            if (cancel && cancel->load())
                return {};
            auto tile = leaf.tile;
            surfaceGrid(
                g->solid, 8,
                [&](double u, double v) {
                    auto d = tileDirection(tile, u, v);
                    return d * (1 + universe_.terrainHeight(n, d) / radius);
                },
                [&](double u, double v, glm::dvec3) {
                    auto d = tileDirection(tile, u, v);
                    return shade(universe_.terrainAlbedo(n, d), universe_.terrainNormal(n, d));
                });
        }
    } else if (kind == Kind::Surface || kind == Kind::Mountain) {
        unsigned cells = 8u << lod;
        surfaceGrid(
            g->solid, cells,
            [&](double u, double v) { return universe_.terrainPoint(n, (u - .5) * 2.4, (v - .5) * 2.4); },
            [&](double u, double v, glm::dvec3) {
                auto d = universe_.terrainDirection(n, (u - .5) * 2.4, (v - .5) * 2.4);
                return shade(universe_.terrainAlbedo(n, d), universe_.terrainNormal(n, d));
            });
    } else if (kind == Kind::Rock || kind == Kind::Grain) {
        std::vector<Node> grains;
        if (kind == Kind::Rock)
            for (auto address : universe_.children(n))
                grains.push_back(universe_.describe(address));
        auto albedo = [&](glm::dvec3 p) {
            auto color = kind == Kind::Rock ? rockAlbedo(n.rock, n.environment.mineral, p)
                                            : material(n.environment.mineral).color;
            // These are the very same grain descriptors exposed to picking and
            // fine meshing, not an independent noise texture or material roll.
            for (const auto& grain : grains) {
                auto local = glm::inverse(grain.frame.orientation) * (p - grain.frame.position) /
                             grain.grainScaleToRock;
                if (glm::length(local) < 1.3) {
                    double sdf = universe_.grainSdf(grain, local);
                    if (sdf < .1)
                        return material(grain.environment.mineral).color;
                }
            }
            return color;
        };
        sdfMesh(
            g->solid,
            [&](glm::dvec3 p) {
                return kind == Kind::Rock ? universe_.rockSdf(n, p) : universe_.grainSdf(n, p);
            },
            8u << lod, albedo, cancel);
        if (kind == Kind::Grain)
            microTint(g->solid, n, [](glm::dvec3 p) { return p; });
    } else if (kind == Kind::Lattice) {
        g->lattice = generateLattice(n);
        for (auto bond : g->lattice.bonds)
            addLine(g->lines, g->lattice.atoms[bond.a].position, g->lattice.atoms[bond.b].position,
                    {.17f, .32f, .4f});
    }
    if (cancel && cancel->load())
        return {};
    g->generationMs =
        std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - begin).count();
    return g;
}
std::shared_ptr<Geometry> GeometryGenerator::section(const Node& parent, const Address& anchor, int bucket,
                                                     const std::atomic<bool>* cancel) const {
    if (parent.address.kind() < Kind::Planet || parent.address.kind() > Kind::Grain ||
        !parent.address.ancestorOf(anchor) || parent.address == anchor || bucket < -22 || bucket > 54)
        throw std::invalid_argument("Invalid local material section");
    auto start = std::chrono::steady_clock::now();
    auto g = std::make_shared<Geometry>();
    g->address = parent.address;
    g->seed = parent.seed;
    g->descriptor = descriptorFingerprint(parent);
    g->referenceFrame = anchor;
    g->logUnits = bucket * .5;
    g->section = true;
    g->inspectionRadius = parent.address.kind() <= Kind::Mountain ? 0 : 1.15;
    auto sourceFrames = universe_.frames(anchor), parentFrames = universe_.frames(parent.address);
    double anchorFactor = std::pow(10.0, g->logUnits - sourceFrames.back().logRadius);
    double parentFactor = std::pow(10.0, parent.frame.logRadius - g->logUnits);
    auto parentPoint = [&](glm::dvec3 p) {
        return relativePoint(sourceFrames, anchor, p * anchorFactor, parentFrames, parent.address,
                             parent.frame.logRadius);
    };
    std::optional<Node> planet;
    std::vector<LocalFrame> planetFrames;
    if (parent.address.kind() <= Kind::Mountain) {
        auto address = parent.address;
        address.path.resize(static_cast<size_t>(Kind::Planet));
        planet = universe_.describe(address);
        planetFrames = universe_.frames(address);
    }
    auto planetPoint = [&](glm::dvec3 p) {
        return relativePoint(sourceFrames, anchor, p * anchorFactor, planetFrames, planet->address,
                             planet->frame.logRadius);
    };
    auto density = [&](glm::dvec3 p) {
        double solid;
        if (planet) {
            auto q = planetPoint(p);
            auto d = glm::normalize(q);
            solid = (glm::length(q) - 1 -
                     universe_.terrainHeight(*planet, d) / std::pow(10.0, planet->frame.logRadius)) *
                    std::pow(10.0, planet->frame.logRadius - g->logUnits);
        } else {
            auto q = parentPoint(p);
            solid = (parent.address.kind() == Kind::Rock ? universe_.rockSdf(parent, q)
                                                         : universe_.grainSdf(parent, q)) *
                    parentFactor;
        }
        // An explicit inspection cavity changes visibility only. The surrounding
        // section is sampled from the actual enclosing object's density/material.
        return g->inspectionRadius > 0 ? std::max(solid, g->inspectionRadius - glm::length(p)) : solid;
    };
    auto color = [&](glm::dvec3 p) {
        if (planet)
            return universe_.terrainAlbedo(*planet, glm::normalize(planetPoint(p)));
        return parent.address.kind() == Kind::Rock
                   ? rockAlbedo(parent.rock, parent.environment.mineral, parentPoint(p))
                   : material(parent.environment.mineral).color;
    };
    sdfMesh(g->solid, density, planet ? 24 : 20, color, cancel, planet ? 4.0 : 1.3);
    if (cancel && cancel->load())
        return {};
    if (parent.address.kind() == Kind::Grain)
        microTint(g->solid, parent, parentPoint);
    g->generationMs =
        std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
    return g;
}
uint64_t geometryFingerprint(const Geometry& g) {
    uint64_t hash = mix64(g.seed ^ g.descriptor ^ g.recipe);
    auto add = [&](uint64_t v) { hash = mix64(hash ^ v); };
    add(std::bit_cast<uint64_t>(g.logUnits));
    add(g.section);
    add(std::bit_cast<uint64_t>(g.inspectionRadius));
    for (auto c : g.referenceFrame.cell)
        add(static_cast<uint64_t>(c));
    for (auto segment : g.referenceFrame.path) {
        add(static_cast<uint64_t>(segment.kind));
        add(segment.id);
    }
    for (auto m : {&g.solid, &g.lines}) {
        for (auto v : m->vertices) {
            add(std::bit_cast<uint32_t>(v.x));
            add(std::bit_cast<uint32_t>(v.y));
            add(std::bit_cast<uint32_t>(v.z));
            add(v.color);
        }
        for (auto i : m->indices)
            add(i);
    }
    for (auto p : g.particles) {
        for (int i = 0; i < 3; ++i) {
            add(std::bit_cast<uint64_t>(p.position[i]));
            add(std::bit_cast<uint32_t>(p.color[i]));
        }
        add(std::bit_cast<uint32_t>(p.radius));
        add(p.objectId);
    }
    for (auto a : g.lattice.atoms) {
        for (int i = 0; i < 3; ++i)
            add(std::bit_cast<uint32_t>(a.position[i]));
        add(a.element);
        add(a.siteId);
        add(std::bit_cast<uint32_t>(a.radius));
    }
    for (auto id : g.lattice.vacantSites)
        add(id);
    for (auto b : g.lattice.bonds) {
        add(b.a);
        add(b.b);
    }
    return hash;
}
unsigned geometryDetail(Kind kind, unsigned requested) {
    requested = std::min(requested, 4u);
    switch (kind) {
    case Kind::Cosmic:
    case Kind::System:
    case Kind::Lattice:
        return 0;
    case Kind::Planet:
        return std::min(requested, 3u);
    case Kind::Rock:
    case Kind::Grain:
        return std::min(requested, 2u);
    default:
        return requested;
    }
}
int sectionBucket(double renderLog) {
    if (!std::isfinite(renderLog) || renderLog < -11 || renderLog > 27)
        throw std::invalid_argument("Invalid section view scale");
    // The entire camera must stay within the inspection cavity. Rounding down
    // would shrink the cavity below the eye when close to a cache boundary.
    return static_cast<int>(std::ceil(renderLog * 2));
}
void GeometryBlend::update(std::shared_ptr<const Geometry> candidate, double seconds) {
    if (candidate && current &&
        (candidate->address != current->address || candidate->seed != current->seed ||
         candidate->descriptor != current->descriptor || candidate->recipe != current->recipe))
        throw std::invalid_argument("Cannot blend different procedural identities");
    if (candidate && candidate != current) {
        if (candidate == previous) {
            std::swap(current, previous);
            blend_ = 1 - blend_;
        } else if (!previous) {
            previous = current;
            current = std::move(candidate);
            blend_ = previous ? 0.f : 1.f;
        }
    }
    blend_ = std::min(1.f, blend_ + static_cast<float>(std::clamp(seconds, 0.0, .1) / .3));
    if (blend_ >= 1)
        previous.reset();
}
} // namespace infinite
