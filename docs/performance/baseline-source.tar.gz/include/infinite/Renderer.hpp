#pragma once
#include "Navigation.hpp"
#include "World.hpp"
#include <memory>
struct SDL_Window;
namespace infinite {
struct FrameStats {
    double cpuMs = 0, gpuMs = 0;
    uint32_t drawCalls = 0;
    size_t gpuBytes = 0, visibleObjects = 0, atoms = 0;
    size_t lodTransitions = 0, sections = 0;
};
class Renderer {
  public:
    Renderer(SDL_Window*, const Universe&);
    ~Renderer();
    Renderer(const Renderer&) = delete;
    Renderer& operator=(const Renderer&) = delete;
    void resize(int width, int height);
    FrameStats render(const Navigation&, RegionCache&, bool overlay, double fps, size_t markers,
                      std::string_view notice);
    std::optional<Address> pick(double x, double y) const;
    void screenshot(const std::string& path);
    std::string backend() const;
    std::shared_ptr<const Geometry> submittedGeometry(const Address&) const;

  private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
} // namespace infinite
