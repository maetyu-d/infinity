#pragma once
#include "Geometry.hpp"
#include <map>
#include <mutex>
#include <oneapi/tbb/task_group.h>
#include <set>
struct sqlite3;

namespace infinite {
struct GenerationStats {
    uint64_t hits = 0, misses = 0, completed = 0, cancelled = 0;
    size_t bytes = 0, pending = 0;
    double lastMs = 0;
    std::string error;
};
class RegionCache {
  public:
    explicit RegionCache(const Universe&, size_t budget = 32 * 1024 * 1024, size_t jobs = 3);
    ~RegionCache();
    void beginFrame();
    std::shared_ptr<const Geometry> request(const Node&, unsigned lod);
    std::shared_ptr<const Geometry> requestSection(const Node&, const Address& anchor, int halfDecade);
    void finishFrame();
    GenerationStats stats() const;
    void clear();
    void wait();

  private:
    struct Entry {
        std::shared_ptr<Geometry> geometry;
        std::shared_ptr<std::atomic<bool>> cancel;
        uint64_t used = 0;
        bool running = false;
    };
    const Universe& universe_;
    size_t budget_, maxJobs_;
    uint64_t frame_ = 0;
    mutable std::mutex mutex_;
    std::map<std::string, Entry> entries_;
    oneapi::tbb::task_group tasks_;
    GenerationStats stats_;
    void trim();
    std::shared_ptr<const Geometry>
    schedule(const Node&, const std::string& prefix, int variant,
             std::function<std::shared_ptr<Geometry>(const std::atomic<bool>*)>,
             std::function<double(const Geometry&)> score);
};
class Persistence {
  public:
    Persistence(const std::string& filename, uint64_t universeSeed);
    ~Persistence();
    Persistence(const Persistence&) = delete;
    Persistence& operator=(const Persistence&) = delete;
    void mark(const Address&, std::string_view note);
    std::optional<std::string> marker(const Address&) const;
    size_t markerCount() const;
    void saveState(std::string_view);
    std::optional<std::string> loadState() const;

  private:
    sqlite3* db_ = nullptr;
    std::string universe_;
    void exec(const char*);
};
} // namespace infinite
