#pragma once
#include "Universe.hpp"
#include <atomic>
#include <functional>

namespace infinite {
struct Vertex {
    float x, y, z;
    uint32_t color;
};
struct Mesh {
    std::vector<Vertex> vertices;
    std::vector<uint32_t> indices;
    size_t bytes() const {
        return vertices.size() * sizeof(Vertex) + indices.size() * 4;
    }
};
struct Particle {
    glm::dvec3 position;
    glm::vec3 color;
    float radius;
    uint64_t objectId = UINT64_MAX; // Exact System ID for addressed galaxy samples.
};
struct Geometry {
    Address address;
    uint64_t seed = 0, descriptor = 0;
    uint32_t recipe = generationRecipeVersion;
    unsigned detail = 0;
    Address referenceFrame;
    double logUnits = 0;
    bool section = false;
    double inspectionRadius = 0;
    Mesh solid, lines;
    std::vector<Particle> particles;
    Lattice lattice;
    double generationMs = 0;
    size_t bytes() const {
        return solid.bytes() + lines.bytes() + particles.size() * sizeof(Particle) +
               lattice.atoms.size() * sizeof(Atom) + lattice.bonds.size() * sizeof(Bond) +
               lattice.vacantSites.size() * sizeof(uint64_t);
    }
};
uint32_t rgba(glm::vec3, float alpha = 1);
glm::vec3 elementColor(uint8_t);
void addLine(Mesh&, glm::dvec3, glm::dvec3, glm::vec3);
void appendSphere(Mesh&, glm::dvec3 center, double radius, glm::vec3 color, unsigned rings = 12,
                  unsigned sectors = 20, bool emissive = false);
struct TerrainLeaf {
    Tile tile;
};
std::vector<TerrainLeaf> terrainLeaves(glm::dvec3 viewDirection, unsigned maxLevel);
class GeometryGenerator {
  public:
    explicit GeometryGenerator(const Universe& universe) : universe_(universe) {}
    std::shared_ptr<Geometry> generate(const Node&, unsigned lod,
                                       const std::atomic<bool>* cancel = nullptr) const;
    std::shared_ptr<Geometry> section(const Node& parent, const Address& anchor, int halfDecade,
                                      const std::atomic<bool>* cancel = nullptr) const;

  private:
    const Universe& universe_;
};
uint64_t geometryFingerprint(const Geometry&);
unsigned geometryDetail(Kind, unsigned requested);
int sectionBucket(double renderLog);
class GeometryBlend {
  public:
    void update(std::shared_ptr<const Geometry> candidate, double seconds);
    std::shared_ptr<const Geometry> current, previous;
    float weight() const {
        return blend_;
    }
    bool active() const {
        return static_cast<bool>(previous);
    }

  private:
    float blend_ = 1;
};
} // namespace infinite
